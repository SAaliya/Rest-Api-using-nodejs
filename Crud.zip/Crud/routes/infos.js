const express = require('express')
const router = express.Router()
const Info = require('../models/info')


router.get('/', async(req,res) => {
   try{
        const allData = await Info.find()
        res.json(allData)
   }
   catch(err){
       res.send('Error while getting data' + err)
   }
})


router.get('/:id', async(req,res) => {
    try{
           const data = await Info.findById(req.params.id)
           res.json(data)
    }
    catch(err){
        res.send('Error while getting data' + err)
    }
})


router.post('/', async(req,res) => {
    const data = new Info({
        name: req.body.name,
        img: req.body.img,
        summary: req.body.summary
    })

    try{
        const a1 =  await data.save() 
        res.json(a1)
    }
    catch(err){
        res.send('Error while inserting data')
    }
})

router.patch('/:id',async(req,res)=> {
    try{
        const data = await Info.findById(req.params.id) 
        data.summary = req.body.summary
        const a1 = await data.save()
        res.json(a1)   
    }catch(err){
        res.send('Error while updating data')
    }
})

router.delete('/:id',async(req,res)=> {
    try{
        const data = await Info.findById(req.params.id) 
        data.summary = req.body.summary
        const a1 = await data.remove()
        res.json(a1)   
    }catch(err){
        res.send('Error while deleting data')
    }
})


module.exports = router